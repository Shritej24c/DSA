# BT3051 Assignment 4
# Roll number: BE14B004
# Collaborators: None
# Time: 1:15

import numpy
import networkx as nx
import matplotlib.pyplot as plt


def barabasi_albert_graph(G, nNodes, mLinks):
    G_new = G.copy()
    initial_nodes = G.number_of_nodes()
    for i in range(initial_nodes + 1, nNodes + initial_nodes + 1):
        total_degree = G_new.number_of_edges() * 2
        current_nodes = [x for x in range(1, i)]
        prob = [(G_new.degree()[x]) / total_degree for x in range(1, i)]
        to_join = numpy.random.choice(current_nodes, size=mLinks, p=prob, replace=False)
        for j in range(mLinks):
            G_new.add_edge(i, to_join[j])
    return G_new


if __name__ == '__main__':
    G = nx.Graph()
    G.add_edge(1, 2)
    G_new = barabasi_albert_graph(G, 98, 1)
    nx.draw(G_new, with_labels=True)
    plt.show(G_new)
